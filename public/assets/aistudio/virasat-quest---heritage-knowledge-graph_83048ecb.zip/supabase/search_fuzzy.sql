create extension if not exists pg_trgm;
create index if not exists sites_name_trgm on heritage_sites using gin (name gin_trgm_ops);
-- Typo-tolerant fallback used by Explore when full-text search returns nothing. Respects RLS.
create or replace function fuzzy_sites(q text) returns setof heritage_sites language sql stable as $$
  select * from heritage_sites where status = 'approved' and similarity(name, q) > 0.25 order by similarity(name, q) desc limit 20 $$;
