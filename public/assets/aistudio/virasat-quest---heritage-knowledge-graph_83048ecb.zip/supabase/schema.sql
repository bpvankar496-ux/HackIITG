create extension if not exists "pgcrypto";
create table heritage_sites(
 id uuid primary key default gen_random_uuid(), slug text unique not null, name text not null,
 state text not null, district text, lat double precision, lng double precision,
 category text not null check (category in ('Stepwells','Forts','Temples','Architecture','Folk Art','Handicrafts','Cultural Traditions')),
 period text, description text, story text, language text default 'en',
 source text, verification text not null default 'unverified' check (verification in ('verified','unverified','community')),
 is_demo boolean not null default false, model_url text,
 status text not null default 'approved' check (status in ('pending','approved','rejected','needs_correction')),
 created_by uuid references auth.users, created_at timestamptz default now(),
 search tsvector generated always as (to_tsvector('simple',
  coalesce(name,'')||' '||coalesce(state,'')||' '||coalesce(district,'')||' '||coalesce(category,'')||' '||coalesce(period,'')||' '||coalesce(description,'')||' '||coalesce(story,'')||' '||coalesce(language,''))) stored);
create index on heritage_sites using gin(search);
create index on heritage_sites(state,category,status);
create table heritage_media(
 id uuid primary key default gen_random_uuid(), site_id uuid not null references heritage_sites on delete cascade,
 url text not null, alt text not null, photographer text not null, license text not null, source_url text not null,
 is_hero boolean default false, created_at timestamptz default now());
create table community_contributions(
 id uuid primary key default gen_random_uuid(), site_id uuid references heritage_sites on delete set null,
 user_id uuid references auth.users, payload jsonb not null, image_paths text[] default '{}',
 status text not null default 'pending' check (status in ('pending','approved','rejected','needs_correction')),
 reviewer_note text, reviewed_by uuid references auth.users, created_at timestamptz default now());
create table quests(id uuid primary key default gen_random_uuid(), slug text unique, title text, intro text);
create table quest_steps(id uuid primary key default gen_random_uuid(), quest_id uuid references quests on delete cascade,
 site_id uuid references heritage_sites, position int not null, story_intro text, clue text, question text,
 options jsonb, correct_index int, explanation text, points int default 20, unique(quest_id,position));
create table user_quest_progress(id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users,
 quest_id uuid references quests, step_id uuid references quest_steps, points int default 0,
 checkin_mode text check (checkin_mode in ('demo','gps_verified')), completed_at timestamptz default now(), unique(user_id,step_id));
create table saved_heritage(user_id uuid references auth.users, site_id uuid references heritage_sites on delete cascade,
 created_at timestamptz default now(), primary key(user_id,site_id));
create table user_badges(user_id uuid references auth.users, badge text, earned_at timestamptz default now(), primary key(user_id,badge));
alter table heritage_sites enable row level security; alter table heritage_media enable row level security;
alter table community_contributions enable row level security; alter table user_quest_progress enable row level security;
alter table saved_heritage enable row level security; alter table user_badges enable row level security;
create policy pub_sites on heritage_sites for select using (status='approved');
create policy pub_media on heritage_media for select using (exists(select 1 from heritage_sites s where s.id=site_id and s.status='approved'));
create policy own_contrib_read on community_contributions for select using (auth.uid()=user_id);
create policy own_contrib_ins on community_contributions for insert with check (auth.uid()=user_id and status='pending');
create policy own_progress on user_quest_progress for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy own_saved on saved_heritage for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy own_badges_read on user_badges for select using (auth.uid()=user_id);
-- Approval and badge awards run server-side with the service role only.
insert into storage.buckets(id,name,public) values('contributions','contributions',true) on conflict do nothing;
