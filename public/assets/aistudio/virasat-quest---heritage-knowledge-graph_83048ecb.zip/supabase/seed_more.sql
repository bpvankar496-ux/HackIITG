-- Additional demo entries (Gujarat to 13 total, plus 4 from other states).
-- Coordinates are approximate and descriptions are deliberately brief: check each
-- against its cited source before marking anything as verified.
insert into heritage_sites(slug,name,state,district,lat,lng,category,period,description,source,verification,is_demo) values
('sidi-saiyyed-mosque','Sidi Saiyyed Mosque','Gujarat','Ahmedabad',23.0276,72.5805,'Architecture','16th century','Mosque in Ahmedabad known for its carved stone latticework (jali) windows.','Demo entry; to verify','unverified',true),
('jama-masjid-ahmedabad','Jama Masjid, Ahmedabad','Gujarat','Ahmedabad',23.0237,72.5817,'Architecture','15th century','Congregational mosque in the old city of Ahmedabad.','Demo entry; to verify','unverified',true),
('historic-city-of-ahmedabad','Historic City of Ahmedabad','Gujarat','Ahmedabad',23.0258,72.5811,'Architecture','15th century onward','Walled city founded in the early 15th century, inscribed by UNESCO in 2017.','UNESCO World Heritage List','verified',true),
('sarkhej-roza','Sarkhej Roza','Gujarat','Ahmedabad',22.9809,72.5016,'Architecture','15th century','Mosque and tomb complex on the outskirts of Ahmedabad.','Demo entry; to verify','unverified',true),
('lothal','Lothal','Gujarat','Ahmedabad',22.5217,72.2494,'Architecture','Harappan era','Harappan-era archaeological site with remains of a settlement and dockyard.','Demo entry; to verify','unverified',true),
('uparkot-fort','Uparkot Fort','Gujarat','Junagadh',21.5260,70.4630,'Forts','Ancient, with later additions','Fort in Junagadh whose origins predate the medieval period.','Demo entry; to verify','unverified',true),
('somnath-temple','Somnath Temple','Gujarat','Gir Somnath',20.8880,70.4010,'Temples','Present structure 1951','Temple on the Saurashtra coast. The present structure was completed in 1951.','Demo entry; to verify','unverified',true),
('patan-patola','Patan Patola','Gujarat','Patan',23.8500,72.1260,'Handicrafts','Living tradition','Double-ikat woven silk textile tradition associated with Patan.','Demo entry; to verify','unverified',true),
('hampi','Group of Monuments at Hampi','Karnataka','Vijayanagara',15.3350,76.4600,'Temples','14th to 16th century','Ruins of the Vijayanagara capital, inscribed by UNESCO in 1986.','UNESCO World Heritage List','verified',true),
('amer-fort','Amer Fort','Rajasthan','Jaipur',26.9855,75.8513,'Forts','16th century onward','Hill fort near Jaipur, part of the UNESCO-listed Hill Forts of Rajasthan.','UNESCO World Heritage List','verified',true),
('konark-sun-temple','Konark Sun Temple','Odisha','Puri',19.8876,86.0945,'Temples','13th century','Sun temple on the Odisha coast, inscribed by UNESCO in 1984.','UNESCO World Heritage List','verified',true),
('madhubani-painting','Madhubani Painting','Bihar','Madhubani',26.3500,86.0700,'Folk Art','Living tradition','Folk painting tradition from the Mithila region of Bihar.','Demo entry; to verify','unverified',true)
on conflict (slug) do nothing;
