-- Coordinates approximate. Photos go into heritage_media only after each
-- Wikimedia Commons file, author and license are checked by hand.
insert into heritage_sites(slug,name,state,district,lat,lng,category,period,description,source,verification,is_demo) values
('rani-ki-vav','Rani ki Vav','Gujarat','Patan',23.8593,72.1017,'Stepwells','11th century','Stepwell in Patan, a UNESCO World Heritage Site.','UNESCO World Heritage List','verified',true),
('adalaj-stepwell','Adalaj Stepwell','Gujarat','Gandhinagar',23.1665,72.5806,'Stepwells','15th century','Stepwell near Ahmedabad.','Demo entry; to verify','unverified',true),
('modhera-sun-temple','Modhera Sun Temple','Gujarat','Mehsana',23.5835,72.1330,'Temples','11th century','Sun temple on the Pushpavati river.','Demo entry; to verify','unverified',true),
('champaner-pavagadh','Champaner-Pavagadh Archaeological Park','Gujarat','Panchmahal',22.4850,73.5340,'Architecture','8th to 16th century','UNESCO World Heritage archaeological park.','UNESCO World Heritage List','verified',true);
-- TODO: 8+ more Gujarat entries and a few from other states.
