-- Progress and GPS check-ins are written server-side only, so clients cannot forge them.
create table if not exists gps_checkins(user_id uuid references auth.users, site_id uuid references heritage_sites, verified_at timestamptz default now(), primary key(user_id, site_id));
alter table gps_checkins enable row level security;
create policy own_gps_read on gps_checkins for select using (auth.uid() = user_id);
drop policy if exists own_progress on user_quest_progress;
create policy own_progress_read on user_quest_progress for select using (auth.uid() = user_id);
