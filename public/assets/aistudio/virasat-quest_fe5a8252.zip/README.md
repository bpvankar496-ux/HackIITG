# Virasat Quest

> **“Discover the stories hidden in our heritage.”**  
> Problem Statement: *Digital Revitalisation of Unstructured Cultural & Architectural Heritage Archives*  
> Developed for: **IIT Guwahati Hackathon**  
> GitHub Repository: [https://github.com/bpvankar496-ux/HackathonIITG](https://github.com/bpvankar496-ux/HackathonIITG)

---

## 1. Project Overview & Architecture

**Virasat Quest** transforms scattered colonial survey monographs (such as Dr. James Burgess's Architectural Surveys of Western India), medieval Sanskrit inscriptions, Persian court charters, and unindexed archaeological field notes into a searchable, verified, and AI-grounded living knowledge archive.

### Core Architectural Pillars
1. **Unstructured Document Ingestion:** Upload historical PDFs, high-resolution manuscript scans, and architectural plates.
2. **Multi-Modal Gemini OCR:** Server-side transcription preserving historical orthography, architectural entities, and page coordinates.
3. **Deep Passage Retrieval:** Granular folio-level search across transcribed passages with source attribution.
4. **Grounded AI Heritage Research Assistant:** Strict RAG pipeline citing verified primary sources with page numbers and distinguishing archival facts from AI commentary.
5. **Geospatial Heritage Map:** Interactive Leaflet cartography linking monuments to their earliest survey documents.
6. **Heritage Knowledge Graph:** Visual network mapping connections between dynasties, royal patrons, regional architectural schools, and primary inscriptions.

---

## 2. Technology Stack

- **Frontend & App Shell:** React 19, TypeScript, Tailwind CSS v4, Lucide Icons
- **Design System:** Editorial museum palette (warm ivory `#FBF9F4`, parchment `#F4EFE6`, deep indigo-charcoal `#16192E`, antique gold `#B38E46`)
- **Database & Authentication:** Supabase (PostgreSQL with Row Level Security and Storage)
- **AI & Multi-Modal Processing:** Google Gemini 2.5 Flash via `@google/genai` TypeScript SDK (server-side)
- **Geospatial Engine:** Leaflet with OpenStreetMap tiles

---

## 3. Database & Storage Architecture (Step 2 Migration)

### PostgreSQL Schema (`public.documents`)
The metadata schema for historical archives is codified in `supabase/schema_step2_documents.sql`:

| Column | Type | Constraints / Description |
|---|---|---|
| `id` | `uuid` | Primary Key, `default gen_random_uuid()` |
| `title` | `text` | Required document title |
| `description` | `text` | Archival summary / context |
| `document_type` | `text` | Check: `manuscript`, `photograph`, `map`, `architectural_record`, `historical_document`, `other` |
| `historical_period`| `text` | Century, era, or dynasty (e.g. `11th century CE`) |
| `language` | `text` | Language / script (e.g. `Sanskrit`, `Gujarati`, `English`) |
| `location_name` | `text` | Geographic place name (e.g. `Patan`, `Modhera`) |
| `latitude`, `longitude` | `float8` | Verified geographic coordinates with [-90, 90] and [-180, 180] checks |
| `source_name` | `text` | Archive repository or collection (e.g. `ASI Calcutta`) |
| `attribution` | `text` | Rights holder, license, or surveyor |
| `storage_path` | `text` | Unique private object path in Supabase Storage |
| `original_filename`| `text` | Original uploaded file name |
| `mime_type` | `text` | Validated MIME type (`application/pdf`, `image/jpeg`, etc.) |
| `file_size_bytes` | `bigint` | File size in bytes (must be > 0) |
| `processing_status`| `text` | Check: `uploaded`, `processing`, `needs_review`, `indexed`, `failed` |
| `verification_status`| `text` | Check: `unverified`, `under_review`, `verified` |
| `created_by` | `uuid` | Foreign key to `auth.users(id)` |
| `created_at`, `updated_at` | `timestamptz` | Timestamps with automated trigger |
| `search_vector` | `tsvector` | Generated full-text search index across title, description, location, era, and source |

### Supabase Storage Vault
- **Bucket ID:** `historical_archives`
- **Visibility:** `Private (public = false)`
- **Max File Size:** `50 MB`
- **Allowed MIME Types:** `application/pdf`, `image/jpeg`, `image/png`, `image/webp`, `image/tiff`
- **Security Policy:** Authenticated upload to user-scoped folder `{user_id}/{filename}`; read restricted to uploaders and verified documents.

---

## 4. Local Development on macOS M1 (Apple Silicon)

### Prerequisites
- Node.js 18.x or 20.x
- npm 9+ or 10+
- Git

### Quickstart
```bash
# 1. Clone repository
git clone https://github.com/bpvankar496-ux/HackathonIITG.git
cd HackathonIITG

# 2. Install dependencies
npm install

# 3. Setup environment variables
cp .env.example .env.local

# 4. Start local development server
npm run dev

# 5. Open in your browser
# http://localhost:3000
```

### Verification & Testing
```bash
# Run all unit tests (heritage logic, upload validation, and OCR pipeline)
npx --yes tsx --test src/utils/heritageLogic.test.ts src/utils/uploadValidation.test.ts src/utils/ocrPipeline.test.ts

# Run production build check
npm run build
```

---

## 5. Text Extraction & OCR Architecture (Step 4)

### Dual-Path Processing Pipeline
1. **Path A — Digital Text-Based PDFs (`pdf-parse`):**
   - Inspects embedded font streams across each page.
   - Preserves page numbers, bounds, and empty pages.
   - Fast, local, deterministic extraction with 0.99 confidence.
2. **Path B — Scanned Manuscripts, Epigraphs, & Images (Google Gemini `gemini-3.8-flash`):**
   - Automatically triggered when a PDF lacks a text stream or when images (`image/jpeg`, `image/png`, `image/webp`) are ingested.
   - Uses scholarly palaeographic instructions preserving Sanskrit (Devanagari), Gujarati, Persian, and colonial English orthography.
   - Supplies granular confidence scores, detects empty visual drawings/photos, and marks unreadable sections as `[illegible]`.

### Page Provenance Schema (`public.document_pages`)
Codified in `supabase/schema_step4_document_pages.sql`:
- Foreign key: `document_id` references `documents(id)` on delete cascade.
- Unique constraint: `(document_id, page_number)` enforces idempotent retries without duplicate page bloat.
- Status values: `completed`, `empty_page`, `needs_review`, `failed`.
- Method tags: `pdf_text_layer`, `gemini_multimodal_ocr`, `empty_page_marker`.

---

## 6. Real Archive Search Architecture (Step 5)

### PostgreSQL Full-Text Search (FTS) & Deterministic Search Engine
Codified in `supabase/schema_step5_search.sql`:
- **GIN Indexes:**
  - `idx_document_pages_fts`: GIN index on `to_tsvector('english', extracted_text)`.
  - `idx_documents_metadata_fts`: GIN index across `title`, `description`, `location_name`, `historical_period`, and `source_name`.
- **Search Function (`search_archive_passages`):** Stored procedure executing joint query across documents and page extractions, generating headlines via `ts_headline`, and ranking results via `ts_rank_cd` and title weight boosting.
- **Resilient Fallback Engine (`src/server/searchRepository.ts`):** Automatically evaluates queries across local vaults if SQL migration is pending in PostgREST, ensuring zero user disruption.
- **XSS-Safe Highlight Segmentation (`src/utils/archiveSearch.ts`):** Tokenizes text into safe alternating match segments rendered natively in React, preventing raw HTML injection vulnerabilities.
- **Multi-Facet Filtering:** Functional filtering by Document Classification, Historical Era, Geographic Location, and Verification Status.
- **Contextual Navigation:** Clicking a search result card opens the document reader directly on the matching folio page.

---

## 7. Environment Variables

Configure your `.env.local` based on `.env.example`:

```env
# Google Gemini API (Server-side only)
GEMINI_API_KEY="your-gemini-api-key"

# Supabase PostgreSQL & Storage Configuration
NEXT_PUBLIC_SUPABASE_URL="https://your-project.supabase.co"
NEXT_PUBLIC_SUPABASE_ANON_KEY="your-anon-key"
SUPABASE_SERVICE_ROLE_KEY="your-service-role-key"

# Admin Authentication
ADMIN_EMAIL="admin@example.com"
ADMIN_PASSWORD="your-admin-password"
```

> **Security Note:** Never commit `.env` or `.env.local` to Git. The `.gitignore` file enforces that all credential files remain local.

---

## 8. Incremental Implementation Roadmap

- [x] **Step 1 — Foundation & Application Shell:** Editorial design system, responsive navigation, landing page with problem statement, and technical placeholder wireframes.
- [x] **Step 2 — Database & Secure Storage:** `documents` metadata table schema, private `historical_archives` storage bucket, RLS access control policies, and diagnostic health check.
- [x] **Step 3 — Document Upload & Private Storage:** Drag-and-drop ingestion, strict MIME/size validation, private storage isolation, and authenticated 300-second signed URL generation.
- [x] **Step 4 — Text Extraction & OCR Pipeline:** Dual-path extraction (PDF text layer + Gemini Multimodal OCR), `document_pages` provenance schema, empty page detection, and interactive page viewer.
- [x] **Step 5 — Deep Searchable Archival Passage Index & Inscription Search:** PostgreSQL FTS GIN indexes, stored procedure `search_archive_passages`, multi-facet filtering (type, period, location, verification), and contextual page navigation.
- [ ] **Step 6 — Grounded Gemini AI Heritage Research Assistant with Evidence Citations.**
- [ ] **Step 7 — Interactive Leaflet Heritage Map & Coordinate Linkage.**
- [ ] **Step 8 — Heritage Knowledge Graph (Monuments, Dynasties, Sources).**
