-- ==============================================================================
-- VIRASAT QUEST — STEP 5 DATABASE MIGRATION: FULL-TEXT ARCHIVE SEARCH
-- Target Platform: Supabase PostgreSQL
-- Problem Statement: Digital Revitalisation of Unstructured Cultural & Architectural Heritage Archives
-- ==============================================================================

-- 1. Full-text search indexes on document pages extracted text
CREATE INDEX IF NOT EXISTS idx_document_pages_fts 
    ON public.document_pages 
    USING gin(to_tsvector('english', coalesce(extracted_text, '')));

-- 2. Full-text search indexes on document metadata
CREATE INDEX IF NOT EXISTS idx_documents_metadata_fts 
    ON public.documents 
    USING gin(
        to_tsvector('english', 
            coalesce(title, '') || ' ' || 
            coalesce(description, '') || ' ' || 
            coalesce(location_name, '') || ' ' || 
            coalesce(historical_period, '') || ' ' || 
            coalesce(source_name, '')
        )
    );

-- 3. Stored RPC function for ranking and snippet extraction
CREATE OR REPLACE FUNCTION public.search_archive_passages(
    search_query text,
    filter_doc_type text DEFAULT 'all',
    filter_period text DEFAULT 'all',
    filter_location text DEFAULT 'all',
    filter_language text DEFAULT 'all',
    filter_verification text DEFAULT 'all',
    limit_val int DEFAULT 40,
    offset_val int DEFAULT 0
)
RETURNS TABLE (
    passage_id uuid,
    document_id uuid,
    page_number int,
    extracted_text text,
    snippet text,
    confidence_score numeric,
    extraction_method text,
    extraction_status text,
    document_title text,
    document_type text,
    historical_period text,
    location_name text,
    language text,
    verification_status text,
    source_name text,
    attribution text,
    storage_path text,
    relevance_rank float4
)
LANGUAGE sql
STABLE
AS $$
    WITH query_terms AS (
        SELECT plainto_tsquery('english', search_query) AS q
    )
    SELECT
        p.id AS passage_id,
        d.id AS document_id,
        p.page_number,
        p.extracted_text,
        ts_headline(
            'english',
            p.extracted_text,
            qt.q,
            'StartSel = <mark>, StopSel = </mark>, MaxWords = 35, MinWords = 15, ShortWord = 3, HighlightAll = FALSE, MaxFragments = 1'
        ) AS snippet,
        p.confidence_score,
        p.extraction_method,
        p.extraction_status,
        d.title AS document_title,
        d.document_type,
        d.historical_period,
        d.location_name,
        d.language,
        d.verification_status,
        d.source_name,
        d.attribution,
        d.storage_path,
        (
            ts_rank_cd(to_tsvector('english', p.extracted_text), qt.q) * 2.0 +
            ts_rank(to_tsvector('english', d.title), qt.q) * 4.0 +
            ts_rank(to_tsvector('english', coalesce(d.location_name, '')), qt.q) * 1.5
        )::float4 AS relevance_rank
    FROM public.document_pages p
    JOIN public.documents d ON p.document_id = d.id
    CROSS JOIN query_terms qt
    WHERE
        (
            search_query IS NULL OR trim(search_query) = '' OR
            to_tsvector('english', p.extracted_text) @@ qt.q OR
            to_tsvector('english', d.title || ' ' || coalesce(d.description, '') || ' ' || coalesce(d.location_name, '')) @@ qt.q
        )
        AND (filter_doc_type = 'all' OR d.document_type = filter_doc_type)
        AND (filter_period = 'all' OR d.historical_period ILIKE '%' || filter_period || '%')
        AND (filter_location = 'all' OR d.location_name ILIKE '%' || filter_location || '%')
        AND (filter_language = 'all' OR d.language ILIKE '%' || filter_language || '%')
        AND (filter_verification = 'all' OR d.verification_status = filter_verification)
    ORDER BY relevance_rank DESC, d.created_at DESC, p.page_number ASC
    LIMIT limit_val
    OFFSET offset_val;
$$;

-- Grant execution permissions
GRANT EXECUTE ON FUNCTION public.search_archive_passages TO anon, authenticated, service_role;
