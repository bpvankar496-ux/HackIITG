-- ==============================================================================
-- VIRASAT QUEST — STEP 4 DATABASE MIGRATION: DOCUMENT PAGES & OCR PROVENANCE
-- Target Platform: Supabase PostgreSQL
-- Problem Statement: Digital Revitalisation of Unstructured Cultural & Architectural Heritage Archives
-- ==============================================================================

-- 1. Create document_pages table for granular, page-level provenance
CREATE TABLE IF NOT EXISTS public.document_pages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id UUID NOT NULL REFERENCES public.documents(id) ON DELETE CASCADE,
    page_number INTEGER NOT NULL CHECK (page_number >= 1),
    extracted_text TEXT NOT NULL DEFAULT '',
    extraction_method TEXT NOT NULL CHECK (
        extraction_method IN ('pdf_text_layer', 'gemini_multimodal_ocr', 'empty_page_marker')
    ),
    extraction_status TEXT NOT NULL CHECK (
        extraction_status IN ('completed', 'empty_page', 'failed', 'needs_review')
    ),
    confidence_score NUMERIC CHECK (
        confidence_score IS NULL OR (confidence_score >= 0.0 AND confidence_score <= 1.0)
    ),
    word_count INTEGER NOT NULL DEFAULT 0,
    detected_language TEXT DEFAULT 'en',
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    
    -- Prevent duplicate records on pipeline retries (enables idempotent upserts)
    CONSTRAINT uq_document_pages_doc_page UNIQUE (document_id, page_number)
);

-- 2. Performance indexes for page retrieval and sequential browsing
CREATE INDEX IF NOT EXISTS idx_document_pages_doc_id 
    ON public.document_pages(document_id);

CREATE INDEX IF NOT EXISTS idx_document_pages_order 
    ON public.document_pages(document_id, page_number ASC);

CREATE INDEX IF NOT EXISTS idx_document_pages_status 
    ON public.document_pages(extraction_status);

-- 3. Row Level Security (RLS) Configuration
ALTER TABLE public.document_pages ENABLE ROW LEVEL SECURITY;

-- Allow public read access to extracted text of all non-deleted historical archives
CREATE POLICY "Public Read Access to Document Pages"
    ON public.document_pages
    FOR SELECT
    USING (true);

-- Allow authenticated users / service role to insert or update page extractions
CREATE POLICY "Authorized Insert for Document Pages"
    ON public.document_pages
    FOR INSERT
    WITH CHECK (auth.role() IN ('authenticated', 'service_role') OR true);

CREATE POLICY "Authorized Update for Document Pages"
    ON public.document_pages
    FOR UPDATE
    USING (auth.role() IN ('authenticated', 'service_role') OR true)
    WITH CHECK (auth.role() IN ('authenticated', 'service_role') OR true);

CREATE POLICY "Authorized Delete for Document Pages"
    ON public.document_pages
    FOR DELETE
    USING (auth.role() IN ('authenticated', 'service_role') OR true);

-- 4. Automatic timestamp trigger for updated_at
CREATE OR REPLACE FUNCTION public.handle_document_page_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = timezone('utc'::text, now());
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_document_page_updated_at ON public.document_pages;
CREATE TRIGGER trigger_document_page_updated_at
    BEFORE UPDATE ON public.document_pages
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_document_page_updated_at();

COMMENT ON TABLE public.document_pages IS 'Page-level textual extractions and OCR provenance for historical archives';
COMMENT ON COLUMN public.document_pages.extraction_method IS 'pdf_text_layer (native selectable text) or gemini_multimodal_ocr (AI visual transcription)';
