-- ============================================================================
-- Virasat Quest: Step 2 — Database and Secure Storage Migration
-- Problem Statement: Digital Revitalisation of Unstructured Cultural & Architectural Heritage Archives
-- ============================================================================

-- 1. Enable required extensions
create extension if not exists "pgcrypto";
create extension if not exists "uuid-ossp";

-- 2. Helper function to maintain updated_at timestamps
create or replace function update_updated_at_column()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

-- 3. Document Metadata Table
create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(trim(title)) > 0),
  description text,
  document_type text not null check (
    document_type in (
      'manuscript',
      'photograph',
      'map',
      'architectural_record',
      'historical_document',
      'other'
    )
  ),
  historical_period text,
  language text default 'en',
  location_name text,
  latitude double precision check (latitude is null or (latitude >= -90.0 and latitude <= 90.0)),
  longitude double precision check (longitude is null or (longitude >= -180.0 and longitude <= 180.0)),
  source_name text,
  attribution text,
  storage_path text not null unique,
  original_filename text not null,
  mime_type text not null check (
    mime_type in (
      'application/pdf',
      'image/jpeg',
      'image/png',
      'image/webp',
      'image/tiff'
    )
  ),
  file_size_bytes bigint not null check (file_size_bytes > 0),
  processing_status text not null default 'uploaded' check (
    processing_status in ('uploaded', 'processing', 'needs_review', 'indexed', 'failed')
  ),
  verification_status text not null default 'unverified' check (
    verification_status in ('unverified', 'under_review', 'verified')
  ),
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  
  -- Future-proofing: Full-text search vector generated column
  search_vector tsvector generated always as (
    to_tsvector('simple',
      coalesce(title, '') || ' ' ||
      coalesce(description, '') || ' ' ||
      coalesce(location_name, '') || ' ' ||
      coalesce(historical_period, '') || ' ' ||
      coalesce(source_name, '') || ' ' ||
      coalesce(attribution, '')
    )
  ) stored
);

-- 4. Indexes for scalable performance
create index if not exists idx_documents_type on public.documents (document_type);
create index if not exists idx_documents_processing_status on public.documents (processing_status);
create index if not exists idx_documents_verification_status on public.documents (verification_status);
create index if not exists idx_documents_location on public.documents (location_name);
create index if not exists idx_documents_created_at on public.documents (created_at desc);
create index if not exists idx_documents_search on public.documents using gin (search_vector);
create index if not exists idx_documents_coords on public.documents (latitude, longitude) where latitude is not null and longitude is not null;

-- 5. Trigger for updated_at
drop trigger if exists trg_documents_updated_at on public.documents;
create trigger trg_documents_updated_at
  before update on public.documents
  for each row
  execute function update_updated_at_column();

-- 6. Row Level Security (RLS) Configuration
alter table public.documents enable row level security;

-- Drop prior policies if updating
drop policy if exists "documents_read_policy" on public.documents;
drop policy if exists "documents_insert_policy" on public.documents;
drop policy if exists "documents_update_policy" on public.documents;
drop policy if exists "documents_delete_policy" on public.documents;

-- Read Policy: Public/authenticated users can view verified historical documents.
-- Unverified or under-review documents can only be viewed by the user who uploaded them.
create policy "documents_read_policy"
  on public.documents
  for select
  using (
    verification_status = 'verified'
    or (auth.uid() is not null and auth.uid() = created_by)
  );

-- Insert Policy: Authenticated users can insert documents with valid created_by link.
create policy "documents_insert_policy"
  on public.documents
  for insert
  with check (
    auth.role() = 'authenticated'
    and auth.uid() = created_by
    and processing_status = 'uploaded'
    and verification_status in ('unverified', 'under_review')
  );

-- Update Policy: Users can only update their own unverified documents.
create policy "documents_update_policy"
  on public.documents
  for update
  using (
    auth.role() = 'authenticated'
    and auth.uid() = created_by
    and verification_status != 'verified'
  )
  with check (
    auth.role() = 'authenticated'
    and auth.uid() = created_by
  );

-- Delete Policy: Users can only delete their own unverified documents.
create policy "documents_delete_policy"
  on public.documents
  for delete
  using (
    auth.role() = 'authenticated'
    and auth.uid() = created_by
    and verification_status != 'verified'
  );

-- ============================================================================
-- 7. Supabase Storage: Private Historical Archives Bucket Setup
-- ============================================================================

-- Create private bucket 'historical_archives' (public = false)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'historical_archives',
  'historical_archives',
  false,
  52428800, -- 50 MB max
  array['application/pdf', 'image/jpeg', 'image/png', 'image/webp', 'image/tiff']
)
on conflict (id) do update set
  public = false,
  file_size_limit = 52428800,
  allowed_mime_types = array['application/pdf', 'image/jpeg', 'image/png', 'image/webp', 'image/tiff'];

-- Storage Object Policies
drop policy if exists "historical_archives_auth_insert" on storage.objects;
drop policy if exists "historical_archives_read_policy" on storage.objects;
drop policy if exists "historical_archives_delete_policy" on storage.objects;

-- Allow authenticated users to upload to user-scoped path: {user_id}/{filename}
create policy "historical_archives_auth_insert"
  on storage.objects
  for insert
  with check (
    bucket_id = 'historical_archives'
    and auth.role() = 'authenticated'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- Read policy: Users can read files they uploaded, or files linked to verified documents.
create policy "historical_archives_read_policy"
  on storage.objects
  for select
  using (
    bucket_id = 'historical_archives'
    and (
      (storage.foldername(name))[1] = auth.uid()::text
      or exists (
        select 1 from public.documents d
        where d.storage_path = name and d.verification_status = 'verified'
      )
    )
  );

-- Delete policy: Users can delete only their own files.
create policy "historical_archives_delete_policy"
  on storage.objects
  for delete
  using (
    bucket_id = 'historical_archives'
    and (storage.foldername(name))[1] = auth.uid()::text
  );
