/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header, NavSection } from './components/Header';
import { Footer } from './components/Footer';
import { LandingPage } from './components/LandingPage';
import { ArchiveExplorerView } from './components/ArchiveExplorerView';
import { DocumentUploadView } from './components/DocumentUploadView';
import {
  KnowledgeGraphPlaceholder,
} from './components/Placeholders';
import { ResearchAssistantView } from './components/ResearchAssistantView';
import { HeritageMapView } from './components/HeritageMapView';
import { ProjectDossier } from './components/ProjectDossier';

export default function App() {
  const [currentSection, setCurrentSection] = useState<NavSection>('overview');

  return (
    <div className="min-h-screen bg-[#FBF9F4] text-[#18191E] flex flex-col font-sans">
      {/* Top Header & Navigation */}
      <Header
        currentSection={currentSection}
        onNavigate={(section) => {
          setCurrentSection(section);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {currentSection === 'overview' && (
          <LandingPage onNavigate={setCurrentSection} />
        )}
        {currentSection === 'explorer' && (
          <ArchiveExplorerView
            onNavigateToUpload={() => setCurrentSection('upload')}
            onNavigateToMap={() => setCurrentSection('map')}
          />
        )}
        {currentSection === 'upload' && (
          <DocumentUploadView
            onUploadSuccess={() => {}}
            onNavigateToArchive={() => setCurrentSection('explorer')}
          />
        )}
        {currentSection === 'assistant' && (
          <ResearchAssistantView
            onNavigateToExplorer={() => setCurrentSection('explorer')}
            onNavigateToUpload={() => setCurrentSection('upload')}
          />
        )}
        {currentSection === 'map' && (
          <HeritageMapView
            onNavigateToExplorer={() => setCurrentSection('explorer')}
            onNavigateToAssistant={() => setCurrentSection('assistant')}
            onNavigateToUpload={() => setCurrentSection('upload')}
          />
        )}
        {currentSection === 'graph' && <KnowledgeGraphPlaceholder />}
        {currentSection === 'dossier' && <ProjectDossier />}
      </main>

      {/* Editorial Footer */}
      <Footer />
    </div>
  );
}
