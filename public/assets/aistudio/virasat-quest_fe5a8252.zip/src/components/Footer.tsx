/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Compass, ExternalLink, Github, Shield } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="border-t border-[#E2D7C3] bg-[#F4EFE6] py-12 text-[#6B6860]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-12">
          {/* Brand & Mission */}
          <div className="md:col-span-5">
            <div className="flex items-center gap-2">
              <Compass className="h-5 w-5 text-[#B38E46]" />
              <span className="font-serif text-lg font-bold text-[#16192E]">
                Virasat Quest
              </span>
            </div>
            <p className="mt-2 text-xs leading-relaxed text-[#6B6860]">
              A scholarly digital platform engineered for the revitalisation of unstructured cultural and architectural heritage archives. Transforming colonial surveys, Sanskrit epigraphs, and regional field reports into verified, navigable historical intelligence.
            </p>
            <div className="mt-4 flex items-center gap-2 text-xs text-[#8E8A81]">
              <Shield className="h-3.5 w-3.5 text-[#B38E46]" />
              <span>Strict source attribution &bull; Zero fabricated historical claims</span>
            </div>
          </div>

          {/* Hackathon Problem Alignment */}
          <div className="md:col-span-4">
            <h4 className="font-serif text-xs font-bold uppercase tracking-wider text-[#16192E]">
              Problem Statement
            </h4>
            <p className="mt-2 text-xs leading-relaxed">
              &ldquo;Digital Revitalisation of Unstructured Cultural & Architectural Heritage Archives&rdquo; &mdash; IIT Guwahati Hackathon.
            </p>
            <div className="mt-3 text-[11px] text-[#8E8A81]">
              Engineered with Next.js / Vite SPA &bull; Supabase PostgreSQL &bull; Google Gemini 2.5 Flash &bull; Leaflet Geospatial Engine.
            </div>
          </div>

          {/* Repository & Links */}
          <div className="md:col-span-3">
            <h4 className="font-serif text-xs font-bold uppercase tracking-wider text-[#16192E]">
              Source Repository
            </h4>
            <ul className="mt-2 space-y-2 text-xs">
              <li>
                <a
                  href="https://github.com/bpvankar496-ux/HackathonIITG"
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1.5 text-[#16192E] hover:text-[#B38E46] transition-colors"
                >
                  <Github className="h-3.5 w-3.5" />
                  <span>bpvankar496-ux/HackathonIITG</span>
                  <ExternalLink className="h-3 w-3 text-[#8E8A81]" />
                </a>
              </li>
              <li className="text-[11px] text-[#8E8A81]">
                Target Architecture: macOS M1 Local Dev & AI Studio Runtime
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 border-t border-[#E2D7C3]/60 pt-6 flex flex-col sm:flex-row items-center justify-between text-[11px] text-[#8E8A81]">
          <span>&copy; {new Date().getFullYear()} Virasat Quest &bull; Open Academic & Cultural Heritage Initiative.</span>
          <span className="mt-2 sm:mt-0 italic font-serif">
            &ldquo;Every Place Has a Story. Every Story Deserves to Live.&rdquo;
          </span>
        </div>
      </div>
    </footer>
  );
};
