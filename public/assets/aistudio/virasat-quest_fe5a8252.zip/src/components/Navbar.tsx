/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Compass, BookOpen, MapPin, Sparkles, Award, Users, FileText } from 'lucide-react';

export type ActiveTab = 'home' | 'explore' | 'archive' | 'ocr' | 'quests' | 'community' | 'passport';

interface NavbarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  savedCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, onSelectTab, savedCount }) => {
  return (
    <header className="sticky top-0 z-40 border-b border-[#DCC9AD] bg-[#F8F5EF]/95 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        {/* Brand */}
        <button
          onClick={() => onSelectTab('home')}
          className="flex items-center gap-3 text-left transition-opacity hover:opacity-80"
          aria-label="Virasat Quest Home"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#B65F43] text-white shadow-sm">
            <Compass className="h-6 w-6 animate-pulse" />
          </div>
          <div>
            <span className="font-serif text-xl font-bold tracking-tight text-[#292821]">
              Virasat Quest
            </span>
            <span className="hidden text-xs text-[#777267] sm:block">
              Digital Heritage & Archival Vault
            </span>
          </div>
        </button>

        {/* Navigation items */}
        <nav className="flex items-center gap-1 sm:gap-2">
          <button
            onClick={() => onSelectTab('explore')}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
              activeTab === 'explore'
                ? 'bg-[#B65F43] text-white'
                : 'text-[#292821] hover:bg-[#DCC9AD]/30'
            }`}
          >
            <MapPin className="h-4 w-4" />
            <span className="hidden md:inline">Heritage Map</span>
          </button>

          <button
            onClick={() => onSelectTab('archive')}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
              activeTab === 'archive'
                ? 'bg-[#B65F43] text-white'
                : 'text-[#292821] hover:bg-[#DCC9AD]/30'
            }`}
          >
            <BookOpen className="h-4 w-4" />
            <span>Archival Vault</span>
          </button>

          <button
            onClick={() => onSelectTab('ocr')}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
              activeTab === 'ocr'
                ? 'bg-[#667653] text-white'
                : 'text-[#667653] hover:bg-[#667653]/10 font-semibold'
            }`}
            title="Digitize Unstructured Historical Archives"
          >
            <Sparkles className="h-4 w-4" />
            <span className="hidden sm:inline">Gemini OCR</span>
          </button>

          <button
            onClick={() => onSelectTab('quests')}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
              activeTab === 'quests'
                ? 'bg-[#B65F43] text-white'
                : 'text-[#292821] hover:bg-[#DCC9AD]/30'
            }`}
          >
            <Award className="h-4 w-4" />
            <span className="hidden md:inline">Quests</span>
          </button>

          <button
            onClick={() => onSelectTab('community')}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
              activeTab === 'community'
                ? 'bg-[#B65F43] text-white'
                : 'text-[#292821] hover:bg-[#DCC9AD]/30'
            }`}
          >
            <Users className="h-4 w-4" />
            <span className="hidden lg:inline">Community</span>
          </button>

          <button
            onClick={() => onSelectTab('passport')}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
              activeTab === 'passport'
                ? 'bg-[#B65F43] text-white'
                : 'border border-[#DCC9AD] bg-white text-[#292821] hover:bg-[#DCC9AD]/20'
            }`}
          >
            <FileText className="h-4 w-4" />
            <span>Passport</span>
            {savedCount > 0 && (
              <span className="ml-1 rounded-full bg-[#B65F43] px-1.5 py-0.5 text-xs text-white">
                {savedCount}
              </span>
            )}
          </button>
        </nav>
      </div>
    </header>
  );
};
