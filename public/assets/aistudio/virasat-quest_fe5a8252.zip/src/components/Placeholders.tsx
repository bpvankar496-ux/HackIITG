/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  BookOpen,
  Sparkles,
  MapPin,
  Network,
  Upload,
  Clock,
  Layers,
  Database,
  Search,
  FileText,
  Sliders,
  CheckCircle2,
} from 'lucide-react';

interface PlaceholderShellProps {
  title: string;
  category: string;
  description: string;
  icon: React.ReactNode;
  featureIndex: string;
  technicalSpecs: {
    targetDatabaseTables: string[];
    plannedComponents: string[];
    aiAndExternalServices: string[];
  };
  wireframePreview: React.ReactNode;
}

const PlaceholderShell: React.FC<PlaceholderShellProps> = ({
  title,
  category,
  description,
  icon,
  featureIndex,
  technicalSpecs,
  wireframePreview,
}) => {
  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      {/* Editorial Status Notice */}
      <div className="rounded-xl border border-[#C9BBA2] bg-[#F4EFE6] p-4 text-[#16192E] shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded border border-[#C9BBA2] bg-[#FBF9F4] text-[#B38E46]">
              <Clock className="h-4 w-4" />
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#B38E46]">
                Scheduled Implementation &bull; {featureIndex}
              </span>
              <h2 className="text-sm font-serif font-bold text-[#16192E]">
                Module Placeholder: Foundation Shell Active
              </h2>
            </div>
          </div>
          <span className="rounded border border-[#C9BBA2] bg-white px-2.5 py-1 text-[11px] font-medium text-[#6B6860]">
            Awaiting Next Feature Prompt
          </span>
        </div>
        <p className="mt-2 text-xs text-[#6B6860] leading-relaxed">
          In accordance with the hackathon incremental development protocol, this module’s foundational shell is established. The live functionality will be activated in the next prompt.
        </p>
      </div>

      {/* Module Overview */}
      <div className="mt-8 border-b border-[#E2D7C3] pb-6">
        <div className="flex items-center gap-2">
          <div className="text-[#B38E46]">{icon}</div>
          <span className="text-xs font-semibold uppercase tracking-wider text-[#6B6860]">
            {category}
          </span>
        </div>
        <h1 className="mt-2 font-serif text-3xl font-bold tracking-tight text-[#16192E]">
          {title}
        </h1>
        <p className="mt-2 max-w-3xl text-sm leading-relaxed text-[#6B6860]">
          {description}
        </p>
      </div>

      {/* Technical Architecture Specs & Planned Wireframe Layout */}
      <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-12">
        {/* Wireframe Preview (8 cols) */}
        <div className="lg:col-span-8">
          <div className="rounded-xl border border-[#E2D7C3] bg-white p-6 shadow-xs">
            <div className="mb-4 flex items-center justify-between border-b border-[#E2D7C3]/60 pb-3">
              <span className="text-xs font-serif font-bold uppercase tracking-wider text-[#16192E]">
                Planned User Interface Architecture
              </span>
              <span className="text-[11px] text-[#8E8A81]">Visual Wireframe Preview</span>
            </div>
            {wireframePreview}
          </div>
        </div>

        {/* Technical Specs & Database Contracts (4 cols) */}
        <div className="space-y-6 lg:col-span-4">
          <div className="rounded-xl border border-[#E2D7C3] bg-[#F4EFE6] p-5">
            <div className="flex items-center gap-2 text-xs font-serif font-bold text-[#16192E]">
              <Database className="h-4 w-4 text-[#B38E46]" />
              <span>Target Database Contracts</span>
            </div>
            <p className="mt-1 text-[11px] text-[#6B6860]">
              PostgreSQL tables mapped in Supabase schema:
            </p>
            <ul className="mt-3 space-y-1.5 text-xs text-[#16192E]">
              {technicalSpecs.targetDatabaseTables.map((tbl, i) => (
                <li key={i} className="flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-[#B38E46]" />
                  <code className="rounded bg-[#EDE5D5] px-1.5 py-0.5 text-[11px] font-mono text-[#16192E]">
                    {tbl}
                  </code>
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-xl border border-[#E2D7C3] bg-white p-5">
            <div className="flex items-center gap-2 text-xs font-serif font-bold text-[#16192E]">
              <Layers className="h-4 w-4 text-[#B38E46]" />
              <span>Modular Components</span>
            </div>
            <ul className="mt-3 space-y-1.5 text-xs text-[#6B6860]">
              {technicalSpecs.plannedComponents.map((comp, i) => (
                <li key={i} className="flex items-center gap-1.5">
                  <CheckCircle2 className="h-3.5 w-3.5 text-[#B38E46]" />
                  <span>{comp}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-xl border border-[#E2D7C3] bg-white p-5">
            <div className="flex items-center gap-2 text-xs font-serif font-bold text-[#16192E]">
              <Sparkles className="h-4 w-4 text-[#B38E46]" />
              <span>Service Integration</span>
            </div>
            <ul className="mt-3 space-y-1.5 text-xs text-[#6B6860]">
              {technicalSpecs.aiAndExternalServices.map((srv, i) => (
                <li key={i} className="flex items-center gap-1.5">
                  <span className="text-[11px] text-[#16192E] font-medium">{srv}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

// ==========================================
// 1. Archive Explorer Placeholder
// ==========================================
export const ArchiveExplorerPlaceholder: React.FC = () => {
  return (
    <PlaceholderShell
      title="Archive Explorer & Passage Retrieval"
      category="Archival Core"
      description="Deep retrieval system querying digitized colonial architectural surveys, archaeological monographs, and epigraphic records at the specific folio, paragraph, and inscription level."
      icon={<BookOpen className="h-5 w-5" />}
      featureIndex="Phase 2 Planned Release"
      technicalSpecs={{
        targetDatabaseTables: ['archive_documents', 'document_passages', 'site_document_links'],
        plannedComponents: ['FolioReaderView', 'PassageSearchFacet', 'CitationCopyModal'],
        aiAndExternalServices: ['PostgreSQL tsvector / pg_trgm', 'Supabase Storage Archival Vault'],
      }}
      wireframePreview={
        <div className="space-y-4 text-xs text-[#6B6860]">
          {/* Mock Search Bar */}
          <div className="flex gap-2">
            <div className="flex flex-1 items-center gap-2 rounded-lg border border-[#E2D7C3] bg-[#FBF9F4] px-3 py-2">
              <Search className="h-4 w-4 text-[#8E8A81]" />
              <span className="text-[#8E8A81]">Search historical passages, inscriptions, surveyor folios...</span>
            </div>
            <div className="flex items-center gap-1.5 rounded-lg border border-[#E2D7C3] px-3 py-2 text-[#16192E]">
              <Sliders className="h-3.5 w-3.5" />
              <span>Filters</span>
            </div>
          </div>

          {/* Wireframe Mock Dual-Pane */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="rounded-lg border border-dashed border-[#C9BBA2] bg-[#F4EFE6]/50 p-4 min-h-[220px] flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-mono text-[#B38E46] uppercase">Left Pane: Scanned Folio Preview</span>
                <p className="mt-1 font-serif text-sm font-bold text-[#16192E]">
                  Report on Antiquities of Kathiawad (Burgess 1876)
                </p>
                <div className="mt-3 aspect-[4/3] rounded border border-[#E2D7C3] bg-[#EDE5D5]/60 flex items-center justify-center text-[11px] text-[#8E8A81]">
                  High-Resolution Plate Viewer with Zoom & Pan
                </div>
              </div>
              <span className="text-[10px] text-[#8E8A81]">Source: ASI Calcutta / Public Domain</span>
            </div>

            <div className="rounded-lg border border-dashed border-[#C9BBA2] bg-[#F4EFE6]/50 p-4 min-h-[220px] flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-mono text-[#B38E46] uppercase">Right Pane: Transcribed Passages</span>
                <p className="mt-1 font-serif text-sm font-bold text-[#16192E]">
                  Verbatim Transcription & Citations
                </p>
                <div className="mt-3 space-y-2">
                  <div className="rounded border border-[#E2D7C3] bg-white p-2.5 text-[11px] leading-relaxed italic text-[#16192E]">
                    &ldquo;The stepwell at Patan, commonly called the Rani-ki-Vav... exhibits stone carving of extraordinary richness...&rdquo;
                  </div>
                  <div className="flex gap-1">
                    <span className="rounded bg-[#EDE5D5] px-1.5 py-0.5 text-[10px]">Queen Udayamati</span>
                    <span className="rounded bg-[#EDE5D5] px-1.5 py-0.5 text-[10px]">Chaulukya Dynasty</span>
                  </div>
                </div>
              </div>
              <span className="text-[10px] text-[#8E8A81]">Folio 1 &bull; 67 words indexed</span>
            </div>
          </div>
        </div>
      }
    />
  );
};

// ==========================================
// 2. AI Research Assistant Placeholder
// ==========================================
export const AiAssistantPlaceholder: React.FC = () => {
  return (
    <PlaceholderShell
      title="Grounded AI Heritage Research Assistant"
      category="AI & Semantic Retrieval"
      description="Interactive historical enquiry assistant powered by Google Gemini 2.5 Flash on the server. Answers user research queries strictly grounded in retrieved archival passages with verified primary source citations."
      icon={<Sparkles className="h-5 w-5" />}
      featureIndex="Phase 3 Planned Release"
      technicalSpecs={{
        targetDatabaseTables: ['document_passages', 'archive_documents'],
        plannedComponents: ['CitationChatInterface', 'SourceProvenanceDrawer', 'FactVsInterpretationBadge'],
        aiAndExternalServices: ['@google/genai (Gemini 2.5 Flash)', 'Server-side Grounded RAG Pipeline'],
      }}
      wireframePreview={
        <div className="space-y-4 text-xs text-[#6B6860]">
          {/* Query Box */}
          <div className="rounded-lg border border-[#E2D7C3] bg-[#FBF9F4] p-3 text-[#8E8A81]">
            Ask a research question (e.g., &ldquo;Who commissioned Rani ki Vav and what do colonial surveys record about its excavation?&rdquo;)
          </div>

          {/* Assistant Response Layout */}
          <div className="rounded-lg border border-dashed border-[#C9BBA2] bg-[#F4EFE6]/50 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono text-[#B38E46] uppercase">Synthesized Response with Strict Attribution</span>
              <span className="rounded bg-emerald-100 px-2 py-0.5 text-[10px] font-medium text-emerald-800">
                Verified Archival Citations
              </span>
            </div>
            <p className="text-xs leading-relaxed text-[#16192E]">
              According to the <strong className="text-[#16192E]">1876 Burgess Architectural Survey [Citation: Doc-1876, Folio 1]</strong>, Rani ki Vav in Patan was commissioned by Queen Udayamati in memory of King Bhima I. The epigraphic records in the <strong className="text-[#16192E]">Prabandha-Chintamani [Citation: Doc-1305, Folio 1]</strong> corroborate that it was constructed across seven subterranean tiers...
            </p>
            <div className="border-t border-[#E2D7C3] pt-2 text-[11px] text-[#8E8A81] flex items-center justify-between">
              <span>Primary sources cited: 2 archival documents</span>
              <span className="underline cursor-pointer">Inspect Evidence Folios &rarr;</span>
            </div>
          </div>
        </div>
      }
    />
  );
};

// ==========================================
// 3. Heritage Map Placeholder
// ==========================================
export const HeritageMapPlaceholder: React.FC = () => {
  return (
    <PlaceholderShell
      title="Geospatial Heritage Map & Monument Atlas"
      category="Geospatial Engine"
      description="Interactive Leaflet mapping system linking geographical coordinates of heritage monuments directly to colonial survey maps, travel itineraries, and localized archival documents."
      icon={<MapPin className="h-5 w-5" />}
      featureIndex="Phase 4 Planned Release"
      technicalSpecs={{
        targetDatabaseTables: ['heritage_sites', 'site_document_links', 'gps_checkins'],
        plannedComponents: ['LeafletMapView', 'MonumentClusterLayer', 'HaversineProximityVerifier'],
        aiAndExternalServices: ['OpenStreetMap Tiles', 'Leaflet Marker Clustering Engine'],
      }}
      wireframePreview={
        <div className="space-y-4 text-xs text-[#6B6860]">
          <div className="aspect-[16/8] rounded-lg border border-dashed border-[#C9BBA2] bg-[#EDE5D5]/50 flex flex-col items-center justify-center p-6 text-center">
            <MapPin className="h-8 w-8 text-[#B38E46] mb-2 animate-bounce" />
            <span className="font-serif text-sm font-bold text-[#16192E]">
              Interactive Leaflet Cartographic Engine
            </span>
            <p className="mt-1 max-w-md text-[11px] text-[#8E8A81]">
              Georeferenced monument pins, cluster zones across Western India, and direct folio overlay cards.
            </p>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center text-[11px]">
            <div className="rounded border border-[#E2D7C3] p-2 bg-white">Patan Cluster (Rani ki Vav)</div>
            <div className="rounded border border-[#E2D7C3] p-2 bg-white">Mehsana (Modhera Sun Temple)</div>
            <div className="rounded border border-[#E2D7C3] p-2 bg-white">Kutch (Dholavira Citadel)</div>
          </div>
        </div>
      }
    />
  );
};

// ==========================================
// 4. Knowledge Graph Placeholder
// ==========================================
export const KnowledgeGraphPlaceholder: React.FC = () => {
  return (
    <PlaceholderShell
      title="Heritage Knowledge Graph & Entity Network"
      category="Relational Network"
      description="Visual semantic network discovering and exposing multi-hop relationships between dynasties (e.g., Solanki/Chaulukya), patrons (Queen Udayamati), architects, architectural styles (Maru-Gurjara), and primary archival sources."
      icon={<Network className="h-5 w-5" />}
      featureIndex="Phase 5 Planned Release"
      technicalSpecs={{
        targetDatabaseTables: ['heritage_entities', 'site_entity_links', 'entity_relationships'],
        plannedComponents: ['NetworkGraphCanvas', 'EntityRelationshipDrawer', 'CrossDynastyComparator'],
        aiAndExternalServices: ['Force-directed Graph Engine / Canvas', 'Gemini Entity Linking'],
      }}
      wireframePreview={
        <div className="space-y-4 text-xs text-[#6B6860]">
          <div className="aspect-[16/8] rounded-lg border border-dashed border-[#C9BBA2] bg-[#F4EFE6] flex flex-col items-center justify-center p-6 text-center">
            <Network className="h-8 w-8 text-[#B38E46] mb-2" />
            <span className="font-serif text-sm font-bold text-[#16192E]">
              Interactive Node & Edge Relational Matrix
            </span>
            <p className="mt-1 max-w-md text-[11px] text-[#8E8A81]">
              Visualising connections between [Queen Udayamati] &rarr; [Rani ki Vav] &rarr; [Maru-Gurjara Style] &larr; [Modhera Sun Temple] &larr; [King Bhima I].
            </p>
          </div>
        </div>
      }
    />
  );
};

// ==========================================
// 5. Upload Folio Placeholder
// ==========================================
export const UploadPlaceholder: React.FC = () => {
  return (
    <PlaceholderShell
      title="Document Intake & Multi-Modal Gemini OCR Ingestion"
      category="Data Ingestion"
      description="Secure portal for uploading unstructured historical PDFs, scanned manuscripts, and architectural sketches, followed by server-side multi-modal text extraction and metadata structuring."
      icon={<Upload className="h-5 w-5" />}
      featureIndex="Phase 1 Ready For Activation"
      technicalSpecs={{
        targetDatabaseTables: ['archive_documents', 'document_passages', 'community_contributions'],
        plannedComponents: ['FolioUploadDropzone', 'OcrProgressIndicator', 'MetadataValidationForm'],
        aiAndExternalServices: ['Google Gemini 2.5 Flash Multi-Modal Vision', 'Supabase Storage Archival Bucket'],
      }}
      wireframePreview={
        <div className="space-y-4 text-xs text-[#6B6860]">
          <div className="rounded-lg border-2 border-dashed border-[#C9BBA2] bg-[#F4EFE6]/60 p-8 text-center flex flex-col items-center justify-center">
            <Upload className="h-8 w-8 text-[#B38E46] mb-2" />
            <span className="font-serif text-sm font-bold text-[#16192E]">
              Historical Manuscript & Document Intake
            </span>
            <p className="mt-1 max-w-sm text-[11px] text-[#8E8A81]">
              Supported: High-resolution TIFF/JPG/PNG scans, archival PDFs. Files will be stored in Supabase Storage with server-side Gemini OCR.
            </p>
            <div className="mt-4 rounded bg-[#16192E] px-4 py-2 text-xs font-semibold text-white">
              Scheduled For Immediate Next Turn
            </div>
          </div>
        </div>
      }
    />
  );
};
