/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Quest, QuestStep, HeritageSite } from '../types';
import { Award, Compass, MapPin, CheckCircle2, AlertTriangle, ArrowRight, RotateCcw } from 'lucide-react';

interface QuestPlayerProps {
  quest: Quest;
  sites: HeritageSite[];
  onSelectSite: (site: HeritageSite) => void;
  onEarnBadge: (badge: string) => void;
}

export const QuestPlayer: React.FC<QuestPlayerProps> = ({
  quest,
  sites,
  onSelectSite,
  onEarnBadge,
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [points, setPoints] = useState<number>(0);
  const [solvedSteps, setSolvedSteps] = useState<{ [stepId: string]: boolean }>({});
  const [checkinModes, setCheckinModes] = useState<{ [stepId: string]: 'demo' | 'gps_verified' }>({});
  const [feedback, setFeedback] = useState<string | null>(null);
  const [feedbackError, setFeedbackError] = useState<string | null>(null);
  const [gpsLoading, setGpsLoading] = useState<boolean>(false);
  const [gpsMessage, setGpsMessage] = useState<string | null>(null);

  const currentStep: QuestStep = quest.steps[currentStepIndex];
  const linkedSite = sites.find((s) => s.slug === currentStep?.site_slug);
  const isCompleted = currentStepIndex >= quest.steps.length;

  const handleAnswer = async (optionIndex: number) => {
    setFeedback(null);
    setFeedbackError(null);

    try {
      const res = await fetch('/api/quest/answer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          correctIndex: currentStep.correct_index,
          chosenIndex: optionIndex,
          stepPoints: currentStep.points,
          explanation: currentStep.explanation,
        }),
      });

      const data = await res.json();
      if (data.correct) {
        setFeedback(data.explanation);
        if (!solvedSteps[currentStep.id]) {
          setPoints((p) => p + currentStep.points);
          const nextSolved = { ...solvedSteps, [currentStep.id]: true };
          setSolvedSteps(nextSolved);

          // Check for badge unlocking
          if (Object.keys(nextSolved).length >= quest.steps.length) {
            onEarnBadge('Gujarat Explorer (Demo)');
          }
        }
      } else {
        setFeedbackError('Not quite. Re-read the architectural clue and try again.');
      }
    } catch {
      // Fallback evaluation
      if (optionIndex === currentStep.correct_index) {
        setFeedback(currentStep.explanation);
        if (!solvedSteps[currentStep.id]) {
          setPoints((p) => p + currentStep.points);
          setSolvedSteps((prev) => ({ ...prev, [currentStep.id]: true }));
        }
      } else {
        setFeedbackError('Not quite. Re-read the architectural clue and try again.');
      }
    }
  };

  const handleDemoCheckin = () => {
    setCheckinModes((prev) => ({ ...prev, [currentStep.id]: 'demo' }));
    setGpsMessage('Demo check-in recorded. Verified on desktop exploration mode.');
  };

  const handleGpsCheckin = () => {
    if (!navigator.geolocation) {
      setGpsMessage('Geolocation is not supported by your browser. Use Demo check-in instead.');
      return;
    }

    setGpsLoading(true);
    setGpsMessage('Requesting device GPS coordinates…');

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const res = await fetch('/api/quest/checkin', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              userLat: pos.coords.latitude,
              userLng: pos.coords.longitude,
              siteLat: linkedSite?.lat,
              siteLng: linkedSite?.lng,
              threshold: 300,
            }),
          });
          const data = await res.json();
          setGpsLoading(false);
          if (data.verified) {
            setCheckinModes((prev) => ({ ...prev, [currentStep.id]: 'gps_verified' }));
            setGpsMessage(`✓ GPS Check-in Verified! You are within ${data.distance}m of ${linkedSite?.name}.`);
          } else {
            setGpsMessage(
              `You are ${data.distance}m away. Must be within 300m for GPS badge. You can use Demo check-in for hackathon testing.`
            );
          }
        } catch {
          setGpsLoading(false);
          setGpsMessage('Unable to connect to check-in service. Use demo check-in.');
        }
      },
      (err) => {
        setGpsLoading(false);
        setGpsMessage(`GPS error: ${err.message}. You can proceed with Demo check-in.`);
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  const handleNextStep = () => {
    setFeedback(null);
    setFeedbackError(null);
    setGpsMessage(null);
    setCurrentStepIndex((prev) => prev + 1);
  };

  const handleResetQuest = () => {
    setCurrentStepIndex(0);
    setPoints(0);
    setSolvedSteps({});
    setCheckinModes({});
    setFeedback(null);
    setFeedbackError(null);
    setGpsMessage(null);
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      {/* Quest Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#DCC9AD] pb-4">
        <div>
          <span className="rounded bg-[#B65F43]/15 px-2.5 py-0.5 text-xs font-semibold text-[#B65F43]">
            Historical Adventure Quest
          </span>
          <h1 className="mt-1 font-serif text-3xl font-bold text-[#292821]">
            {quest.title}
          </h1>
          <p className="mt-1 text-sm text-[#777267]">{quest.intro}</p>
        </div>

        <div className="flex items-center gap-4">
          <div className="rounded-xl border border-[#DCC9AD] bg-white px-4 py-2 text-center shadow-sm">
            <span className="block text-xs uppercase tracking-wider text-[#777267]">Score</span>
            <span className="font-serif text-2xl font-bold text-[#B65F43]">{points} pts</span>
          </div>
          <button
            onClick={handleResetQuest}
            className="flex items-center gap-1 rounded border border-[#DCC9AD] bg-white px-3 py-1.5 text-xs text-[#777267] hover:text-[#292821]"
            title="Reset Quest"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      {/* Quest Completed View */}
      {isCompleted ? (
        <div className="mt-8 rounded-2xl border border-[#DCC9AD] bg-white p-8 text-center shadow-md animate-in fade-in">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-amber-100 text-[#B65F43]">
            <Award className="h-8 w-8" />
          </div>
          <h2 className="mt-4 font-serif text-3xl font-bold text-[#292821]">
            Quest Completed!
          </h2>
          <p className="mt-2 text-base text-[#777267]">
            You have successfully explored all 5 historical landmarks of Gujarat and accumulated{' '}
            <strong className="text-[#B65F43]">{points} points</strong>.
          </p>

          <div className="mx-auto mt-6 max-w-md rounded-xl border border-[#DCC9AD] bg-[#F8F5EF] p-4 text-left">
            <span className="text-xs font-bold uppercase tracking-wider text-[#667653]">
              Badges Unlocked:
            </span>
            <div className="mt-2 flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-emerald-600" />
              <div>
                <strong className="text-sm text-[#292821]">Gujarat Explorer (Demo)</strong>
                <p className="text-xs text-[#777267]">Master of Gujarat’s historical archives.</p>
              </div>
            </div>
          </div>

          <button
            onClick={handleResetQuest}
            className="mt-6 rounded-lg bg-[#B65F43] px-6 py-2.5 font-medium text-white transition-opacity hover:opacity-90 shadow-sm"
          >
            Play Quest Again
          </button>
        </div>
      ) : (
        /* Active Step Card */
        <div className="mt-8 rounded-2xl border border-[#DCC9AD] bg-white p-6 shadow-md">
          {/* Step Progress Indicator */}
          <div className="flex items-center justify-between text-xs text-[#777267]">
            <span className="font-semibold text-[#B65F43]">
              Stage {currentStep.position} of {quest.steps.length}
            </span>
            <span>Worth {currentStep.points} points</span>
          </div>

          {/* Fiction Narrative */}
          <div className="mt-3 rounded-lg border-l-4 border-[#B65F43] bg-[#F8F5EF] p-4 font-serif text-base italic text-[#292821]">
            {currentStep.story_intro}
          </div>

          {/* Historical Fact Clue */}
          <div className="mt-4 rounded-lg border border-[#DCC9AD]/80 bg-amber-50/50 p-4">
            <span className="text-xs font-bold uppercase tracking-wider text-[#B65F43]">
              Verified Archival Clue:
            </span>
            <p className="mt-1 text-sm font-medium text-[#292821]">{currentStep.clue}</p>
          </div>

          {/* Linked Monument & Check-in */}
          {linkedSite && (
            <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-[#DCC9AD] p-3 text-xs">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-[#B65F43]" />
                <span>
                  Target Monument: <strong>{linkedSite.name}</strong> ({linkedSite.district}, {linkedSite.state})
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onSelectSite(linkedSite)}
                  className="text-[#B65F43] underline hover:opacity-80"
                >
                  View Details
                </button>
                <button
                  onClick={handleDemoCheckin}
                  className="rounded bg-stone-100 px-2.5 py-1 text-stone-700 hover:bg-stone-200 border border-stone-300"
                >
                  Demo Check-in
                </button>
                <button
                  onClick={handleGpsCheckin}
                  disabled={gpsLoading}
                  className="rounded bg-[#667653] px-2.5 py-1 text-white hover:opacity-90 disabled:opacity-50"
                >
                  {gpsLoading ? 'Locating…' : 'GPS Check-in'}
                </button>
              </div>
            </div>
          )}

          {gpsMessage && (
            <div className="mt-2 text-xs font-medium text-[#667653]">{gpsMessage}</div>
          )}

          {/* Quiz Question */}
          <div className="mt-6 border-t border-[#DCC9AD]/70 pt-6">
            <h3 className="font-serif text-lg font-bold text-[#292821]">
              {currentStep.question}
            </h3>

            <div className="mt-4 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {currentStep.options.map((option, idx) => {
                const isSelectedAndCorrect =
                  solvedSteps[currentStep.id] && idx === currentStep.correct_index;
                return (
                  <button
                    key={idx}
                    onClick={() => handleAnswer(idx)}
                    className={`rounded-xl border p-3.5 text-left text-sm font-medium transition-all ${
                      isSelectedAndCorrect
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-900 ring-2 ring-emerald-500'
                        : 'border-[#DCC9AD] bg-white text-[#292821] hover:border-[#B65F43] hover:bg-[#F8F5EF]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span>{option}</span>
                      {isSelectedAndCorrect && (
                        <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Feedback & Navigation */}
          {feedbackError && (
            <div className="mt-4 flex items-center gap-2 rounded-lg bg-red-50 p-3 text-xs text-red-700">
              <AlertTriangle className="h-4 w-4 shrink-0" />
              <span>{feedbackError}</span>
            </div>
          )}

          {feedback && (
            <div className="mt-4 rounded-lg bg-emerald-50 p-4 text-xs text-emerald-900">
              <span className="font-bold text-emerald-800">Correct! Archival Note:</span>
              <p className="mt-1 leading-relaxed">{feedback}</p>
            </div>
          )}

          {solvedSteps[currentStep.id] && (
            <div className="mt-6 flex justify-end">
              <button
                onClick={handleNextStep}
                className="flex items-center gap-1.5 rounded-lg bg-[#B65F43] px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition-opacity hover:opacity-90"
              >
                <span>Continue to Next Stage</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
