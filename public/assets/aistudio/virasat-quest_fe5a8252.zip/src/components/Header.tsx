/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Compass,
  BookOpen,
  Sparkles,
  MapPin,
  Network,
  Upload,
  Info,
} from 'lucide-react';

export type NavSection =
  | 'overview'
  | 'explorer'
  | 'assistant'
  | 'map'
  | 'graph'
  | 'upload'
  | 'dossier';

interface HeaderProps {
  currentSection: NavSection;
  onNavigate: (section: NavSection) => void;
}

export const Header: React.FC<HeaderProps> = ({ currentSection, onNavigate }) => {
  const navItems: { id: NavSection; label: string; icon: React.ReactNode }[] = [
    { id: 'overview', label: 'Overview', icon: <Compass className="h-4 w-4" /> },
    { id: 'explorer', label: 'Archive Explorer', icon: <BookOpen className="h-4 w-4" /> },
    { id: 'assistant', label: 'AI Assistant', icon: <Sparkles className="h-4 w-4" /> },
    { id: 'map', label: 'Heritage Map', icon: <MapPin className="h-4 w-4" /> },
    { id: 'graph', label: 'Knowledge Graph', icon: <Network className="h-4 w-4" /> },
    { id: 'upload', label: 'Upload Folio', icon: <Upload className="h-4 w-4" /> },
    { id: 'dossier', label: 'Project Dossier', icon: <Info className="h-4 w-4" /> },
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-[#E2D7C3] bg-[#FBF9F4]/95 backdrop-blur-md">
      {/* Top Banner: Problem Statement & Hackathon Context */}
      <div className="border-b border-[#E2D7C3]/60 bg-[#16192E] px-4 py-1.5 text-center text-[11px] text-[#EDE5D5] tracking-wide">
        <span className="font-serif italic text-[#C9A45C]">Problem Statement:</span> Digital Revitalisation of Unstructured Cultural & Architectural Heritage Archives &bull; <span className="text-[#A7A9B4]">IIT Guwahati Hackathon</span>
      </div>

      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        {/* Brand Lockup */}
        <button
          onClick={() => onNavigate('overview')}
          className="group flex items-center gap-3 text-left transition-opacity hover:opacity-90"
          aria-label="Virasat Quest — Home"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded border border-[#C9BBA2] bg-[#F4EFE6] text-[#B38E46] transition-colors group-hover:border-[#B38E46]">
            <Compass className="h-5 w-5 stroke-[1.75]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-serif text-xl font-bold tracking-tight text-[#16192E]">
                Virasat Quest
              </span>
              <span className="rounded-sm border border-[#E2D7C3] bg-[#F4EFE6] px-1.5 py-0.2 text-[10px] font-medium uppercase tracking-wider text-[#B38E46]">
                Archive Shell
              </span>
            </div>
            <p className="text-[11px] text-[#6B6860] font-normal">
              Discover the stories hidden in our heritage
            </p>
          </div>
        </button>

        {/* Primary Editorial Navigation */}
        <nav className="hidden lg:flex items-center gap-1" aria-label="Main Navigation">
          {navItems.map((item) => {
            const isActive = currentSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`relative flex items-center gap-1.5 px-3 py-2 text-xs font-medium tracking-wide transition-colors ${
                  isActive
                    ? 'text-[#16192E] font-semibold'
                    : 'text-[#6B6860] hover:text-[#16192E]'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
                {isActive && (
                  <span className="absolute bottom-0 left-3 right-3 h-[2px] bg-[#B38E46]" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Mobile / Compact Navigation Bar */}
        <div className="flex lg:hidden items-center gap-1">
          <select
            value={currentSection}
            onChange={(e) => onNavigate(e.target.value as NavSection)}
            className="rounded border border-[#E2D7C3] bg-[#F4EFE6] px-2.5 py-1.5 text-xs font-medium text-[#16192E] focus:outline-none"
            aria-label="Navigate sections"
          >
            {navItems.map((item) => (
              <option key={item.id} value={item.id}>
                {item.label}
              </option>
            ))}
          </select>
        </div>
      </div>
    </header>
  );
};
