/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Compass,
  BookOpen,
  Sparkles,
  MapPin,
  Network,
  Upload,
  ArrowRight,
  ShieldCheck,
  FileText,
  Landmark,
  Layers,
} from 'lucide-react';
import { NavSection } from './Header';

interface LandingPageProps {
  onNavigate: (section: NavSection) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  return (
    <div className="bg-[#FBF9F4] text-[#18191E]">
      {/* Editorial Hero Section */}
      <section className="border-b border-[#E2D7C3] bg-gradient-to-b from-[#F4EFE6] to-[#FBF9F4] py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="mx-auto max-w-3xl text-center">
            {/* Tagline / Subtitle */}
            <div className="inline-flex items-center gap-2 rounded-full border border-[#C9BBA2] bg-white px-3.5 py-1 text-xs font-semibold text-[#B38E46]">
              <Compass className="h-3.5 w-3.5 text-[#B38E46]" />
              <span>Discover the stories hidden in our heritage</span>
            </div>

            <h1 className="mt-6 font-serif text-4xl font-bold tracking-tight text-[#16192E] sm:text-5xl lg:text-6xl leading-[1.15]">
              Digital Revitalisation of Unstructured Cultural &amp; Architectural Heritage Archives.
            </h1>

            <p className="mt-6 text-base sm:text-lg leading-relaxed text-[#6B6860]">
              From scattered colonial surveys and centuries-old Sanskrit manuscripts to a searchable, verified, and AI-grounded living knowledge archive.
            </p>

            {/* Navigation Buttons to Future Archive Features */}
            <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={() => onNavigate('explorer')}
                className="flex items-center gap-2 rounded-lg bg-[#16192E] px-5 py-3 text-sm font-semibold text-white shadow-xs transition-colors hover:bg-[#272B40]"
              >
                <BookOpen className="h-4 w-4 text-[#C9A45C]" />
                <span>Explore Archival Vault</span>
                <ArrowRight className="h-4 w-4 text-[#C9A45C]" />
              </button>

              <button
                onClick={() => onNavigate('upload')}
                className="flex items-center gap-2 rounded-lg border border-[#C9BBA2] bg-white px-5 py-3 text-sm font-semibold text-[#16192E] transition-colors hover:bg-[#F4EFE6]"
              >
                <Upload className="h-4 w-4 text-[#B38E46]" />
                <span>Upload Historical Folio</span>
              </button>

              <button
                onClick={() => onNavigate('assistant')}
                className="flex items-center gap-2 rounded-lg border border-[#C9BBA2] bg-white px-5 py-3 text-sm font-semibold text-[#16192E] transition-colors hover:bg-[#F4EFE6]"
              >
                <Sparkles className="h-4 w-4 text-[#B38E46]" />
                <span>AI Research Assistant</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* The Archival Challenge & Problem Statement Explanation */}
      <section className="py-16 sm:py-20 border-b border-[#E2D7C3]">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:items-center">
            {/* Left Narrative (7 cols) */}
            <div className="lg:col-span-7">
              <span className="text-xs font-bold uppercase tracking-wider text-[#B38E46]">
                The Cultural Challenge
              </span>
              <h2 className="mt-2 font-serif text-3xl font-bold tracking-tight text-[#16192E] sm:text-4xl">
                Millions of historical records remain trapped in unstructured formats.
              </h2>
              <p className="mt-4 text-sm leading-relaxed text-[#6B6860]">
                India&apos;s architectural legacy is documented across hundreds of thousands of fragmented colonial survey reports (such as Dr. James Burgess&apos;s 19th-century Architectural Surveys), Sanskrit stone epigraphs, Persian administrative charters, and local oral narratives.
              </p>
              <p className="mt-3 text-sm leading-relaxed text-[#6B6860]">
                Traditional archives present severe limitations: documents are unindexed, scanned pages cannot be cross-referenced, architectural terms are buried in prose, and modern AI tools frequently hallucinate non-existent historical facts.
              </p>

              <div className="mt-6 rounded-xl border border-[#E2D7C3] bg-[#F4EFE6] p-4 text-xs text-[#16192E] space-y-2">
                <div className="font-serif font-bold text-sm text-[#16192E]">The Virasat Quest Solution:</div>
                <div className="flex items-start gap-2">
                  <span className="text-[#B38E46] font-bold">&bull;</span>
                  <span><strong>Multi-Modal Ingestion:</strong> Transcribing old scripts and colonial plates verbatim with page-level coordinates.</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-[#B38E46] font-bold">&bull;</span>
                  <span><strong>Source Attribution:</strong> Differentiating verified primary records from AI interpretations with exact folio citations.</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-[#B38E46] font-bold">&bull;</span>
                  <span><strong>Spatial &amp; Semantic Mapping:</strong> Connecting physical monuments on Leaflet maps with their original historical manuscripts.</span>
                </div>
              </div>
            </div>

            {/* Right Authentic Archival Spotlight Card (5 cols) */}
            <div className="lg:col-span-5">
              <div className="overflow-hidden rounded-2xl border border-[#C9BBA2] bg-white shadow-md">
                <div className="relative">
                  <img
                    src="https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=1000&q=80"
                    alt="Intricate carved subterranean galleries of Rani ki Vav in Patan"
                    className="aspect-[16/10] w-full object-cover"
                  />
                  <div className="absolute top-3 left-3 rounded bg-[#16192E]/85 px-2.5 py-1 text-[11px] font-medium text-white backdrop-blur-xs">
                    Primary Case Study: Rani ki Vav
                  </div>
                </div>

                <div className="p-5">
                  <div className="flex items-center justify-between text-xs text-[#6B6860]">
                    <span className="font-semibold text-[#B38E46]">Patan, Gujarat</span>
                    <span>11th Century CE</span>
                  </div>
                  <h3 className="mt-1 font-serif text-xl font-bold text-[#16192E]">
                    The Subterranean Inverted Temple
                  </h3>
                  <p className="mt-2 text-xs leading-relaxed text-[#6B6860]">
                    Attributed to Queen Udayamati (1063 CE) in memory of King Bhima I. Rediscovered and excavated after centuries of siltation, its seven subterranean terraces house over 500 principal sculptures.
                  </p>

                  <div className="mt-4 border-t border-[#E2D7C3] pt-3 text-[11px] text-[#8E8A81] flex items-center justify-between">
                    <span>Cited in Burgess Survey (1876, Folio 1)</span>
                    <button
                      onClick={() => onNavigate('explorer')}
                      className="font-semibold text-[#B38E46] hover:underline"
                    >
                      Read Folio &rarr;
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Feature Pathways (Future Modules Overview) */}
      <section className="py-16 sm:py-20 bg-[#F4EFE6]/60">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="text-center">
            <span className="text-xs font-bold uppercase tracking-wider text-[#B38E46]">
              Modular Architecture
            </span>
            <h2 className="mt-2 font-serif text-3xl font-bold tracking-tight text-[#16192E]">
              Core Pillars of the Heritage Intelligence System
            </h2>
            <p className="mt-2 max-w-2xl mx-auto text-sm text-[#6B6860]">
              Explore the five foundational modules engineered for the revitalization workflow.
            </p>
          </div>

          <div className="mt-12 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {/* Pillar 1 */}
            <div
              onClick={() => onNavigate('explorer')}
              className="group cursor-pointer rounded-xl border border-[#E2D7C3] bg-white p-6 transition-all hover:border-[#B38E46] hover:shadow-md flex flex-col justify-between"
            >
              <div>
                <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-[#C9BBA2] bg-[#FBF9F4] text-[#B38E46] transition-colors group-hover:bg-[#16192E] group-hover:text-white">
                  <BookOpen className="h-5 w-5" />
                </div>
                <h3 className="mt-4 font-serif text-lg font-bold text-[#16192E] group-hover:text-[#B38E46]">
                  Archival Explorer
                </h3>
                <p className="mt-2 text-xs leading-relaxed text-[#6B6860]">
                  Deep passage retrieval across digitized colonial monographs, epigraphs, and gazetteers with synchronized dual-pane original scan readers.
                </p>
              </div>
              <div className="mt-4 flex items-center gap-1 text-xs font-medium text-[#B38E46]">
                <span>Inspect module</span>
                <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
              </div>
            </div>

            {/* Pillar 2 */}
            <div
              onClick={() => onNavigate('upload')}
              className="group cursor-pointer rounded-xl border border-[#E2D7C3] bg-white p-6 transition-all hover:border-[#B38E46] hover:shadow-md flex flex-col justify-between"
            >
              <div>
                <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-[#C9BBA2] bg-[#FBF9F4] text-[#B38E46] transition-colors group-hover:bg-[#16192E] group-hover:text-white">
                  <Upload className="h-5 w-5" />
                </div>
                <h3 className="mt-4 font-serif text-lg font-bold text-[#16192E] group-hover:text-[#B38E46]">
                  Document Ingestion &amp; OCR
                </h3>
                <p className="mt-2 text-xs leading-relaxed text-[#6B6860]">
                  Upload historical PDFs and scanned manuscript plates. Gemini multi-modal OCR extracts verbatim text and structures historical metadata.
                </p>
              </div>
              <div className="mt-4 flex items-center gap-1 text-xs font-medium text-[#B38E46]">
                <span>Inspect module</span>
                <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
              </div>
            </div>

            {/* Pillar 3 */}
            <div
              onClick={() => onNavigate('assistant')}
              className="group cursor-pointer rounded-xl border border-[#E2D7C3] bg-white p-6 transition-all hover:border-[#B38E46] hover:shadow-md flex flex-col justify-between"
            >
              <div>
                <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-[#C9BBA2] bg-[#FBF9F4] text-[#B38E46] transition-colors group-hover:bg-[#16192E] group-hover:text-white">
                  <Sparkles className="h-5 w-5" />
                </div>
                <h3 className="mt-4 font-serif text-lg font-bold text-[#16192E] group-hover:text-[#B38E46]">
                  Grounded AI Assistant
                </h3>
                <p className="mt-2 text-xs leading-relaxed text-[#6B6860]">
                  A scholarly research assistant that retrieves evidence before generating answers, citing primary source documents and exact page numbers.
                </p>
              </div>
              <div className="mt-4 flex items-center gap-1 text-xs font-medium text-[#B38E46]">
                <span>Inspect module</span>
                <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
              </div>
            </div>

            {/* Pillar 4 */}
            <div
              onClick={() => onNavigate('map')}
              className="group cursor-pointer rounded-xl border border-[#E2D7C3] bg-white p-6 transition-all hover:border-[#B38E46] hover:shadow-md flex flex-col justify-between"
            >
              <div>
                <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-[#C9BBA2] bg-[#FBF9F4] text-[#B38E46] transition-colors group-hover:bg-[#16192E] group-hover:text-white">
                  <MapPin className="h-5 w-5" />
                </div>
                <h3 className="mt-4 font-serif text-lg font-bold text-[#16192E] group-hover:text-[#B38E46]">
                  Geospatial Heritage Map
                </h3>
                <p className="mt-2 text-xs leading-relaxed text-[#6B6860]">
                  Interactive Leaflet cartography anchoring physical architectural coordinates directly to regional historical texts and field surveys.
                </p>
              </div>
              <div className="mt-4 flex items-center gap-1 text-xs font-medium text-[#B38E46]">
                <span>Inspect module</span>
                <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
              </div>
            </div>

            {/* Pillar 5 */}
            <div
              onClick={() => onNavigate('graph')}
              className="group cursor-pointer rounded-xl border border-[#E2D7C3] bg-white p-6 transition-all hover:border-[#B38E46] hover:shadow-md flex flex-col justify-between"
            >
              <div>
                <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-[#C9BBA2] bg-[#FBF9F4] text-[#B38E46] transition-colors group-hover:bg-[#16192E] group-hover:text-white">
                  <Network className="h-5 w-5" />
                </div>
                <h3 className="mt-4 font-serif text-lg font-bold text-[#16192E] group-hover:text-[#B38E46]">
                  Heritage Knowledge Graph
                </h3>
                <p className="mt-2 text-xs leading-relaxed text-[#6B6860]">
                  Multi-hop relational discovery connecting dynasties, royal patrons, regional architectural schools, and primary historical inscriptions.
                </p>
              </div>
              <div className="mt-4 flex items-center gap-1 text-xs font-medium text-[#B38E46]">
                <span>Inspect module</span>
                <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
              </div>
            </div>

            {/* Pillar 6: Project Dossier */}
            <div
              onClick={() => onNavigate('dossier')}
              className="group cursor-pointer rounded-xl border border-[#E2D7C3] bg-white p-6 transition-all hover:border-[#B38E46] hover:shadow-md flex flex-col justify-between"
            >
              <div>
                <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-[#C9BBA2] bg-[#FBF9F4] text-[#B38E46] transition-colors group-hover:bg-[#16192E] group-hover:text-white">
                  <Layers className="h-5 w-5" />
                </div>
                <h3 className="mt-4 font-serif text-lg font-bold text-[#16192E] group-hover:text-[#B38E46]">
                  Project Dossier &amp; Architecture
                </h3>
                <p className="mt-2 text-xs leading-relaxed text-[#6B6860]">
                  Comprehensive technical documentation, evaluation criteria weights, Supabase configuration, and macOS M1 Git synchronization guide.
                </p>
              </div>
              <div className="mt-4 flex items-center gap-1 text-xs font-medium text-[#B38E46]">
                <span>Inspect module</span>
                <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
