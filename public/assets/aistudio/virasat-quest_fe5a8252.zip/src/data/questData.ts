/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Quest } from '../types';

export const GUJARAT_QUEST: Quest = {
  id: 'quest-gujarat',
  slug: 'lost-stories-of-gujarat',
  title: 'The Lost Stories of Gujarat',
  intro:
    'A heritage expedition across Gujarat’s historic landmarks. Clues marked "Fact" are verified against primary archival records and colonial architectural surveys.',
  steps: [
    {
      id: 'step-1',
      position: 1,
      site_slug: 'rani-ki-vav',
      story_intro:
        'Fiction: A faded archival map leads you down a monumental stone stairway descending deep into the subterranean earth.',
      clue: 'Fact: Rani ki Vav is an 11th-century stepwell, inscribed as a UNESCO World Heritage Site in 2014.',
      question: 'In which ancient capital town is Rani ki Vav located?',
      options: ['Patan', 'Surat', 'Bhuj', 'Junagadh'],
      correct_index: 0,
      explanation:
        'Rani ki Vav stands in Patan (ancient Anahilapataka), the former capital of the Chaulukya (Solanki) dynasty in northern Gujarat.',
      points: 20,
    },
    {
      id: 'step-2',
      position: 2,
      site_slug: 'adalaj-stepwell',
      story_intro:
        'Fiction: The next page of the survey diary smells of cool wet stone and old desert rain.',
      clue: 'Fact: Adalaj Stepwell is a 15th-century stepwell built in 1498 CE near Ahmedabad.',
      question: 'Which city is the Adalaj Stepwell closest to?',
      options: ['Rajkot', 'Ahmedabad', 'Vadodara', 'Surat'],
      correct_index: 1,
      explanation:
        'Adalaj lies just 18 kilometres north of Ahmedabad in the Gandhinagar district.',
      points: 20,
    },
    {
      id: 'step-3',
      position: 3,
      site_slug: 'modhera-sun-temple',
      story_intro:
        'Fiction: An inscription fragment says dawn’s equinox light holds the secret.',
      clue: 'Fact: Modhera Sun Temple was constructed in the early 11th century under the Solanki ruler King Bhima I.',
      question: 'To which solar deity is the Modhera temple dedicated?',
      options: ['Hanuman', 'Ganesha', 'Surya', 'Vishnu'],
      correct_index: 2,
      explanation:
        'Modhera is dedicated to Surya, the solar deity, and is oriented so that the rising sun illuminates the sanctum on equinox days.',
      points: 20,
    },
    {
      id: 'step-4',
      position: 4,
      site_slug: 'champaner-pavagadh',
      story_intro:
        'Fiction: A paved military trail climbs up an ancient fortress ridge toward a sacred hill.',
      clue: 'Fact: Champaner-Pavagadh Archaeological Park was inscribed as a UNESCO World Heritage Site.',
      question: 'In which year was Champaner-Pavagadh inscribed as a UNESCO World Heritage Site?',
      options: ['1994', '2004', '2014', '2021'],
      correct_index: 1,
      explanation:
        'UNESCO inscribed Champaner-Pavagadh on the World Heritage List in 2004.',
      points: 20,
    },
    {
      id: 'step-5',
      position: 5,
      site_slug: 'dholavira',
      story_intro:
        'Fiction: The final riddle lies buried in a fortified citadel older than recorded dynastic annals.',
      clue: 'Fact: Dholavira, located in Khadir bet of Kutch, was inscribed by UNESCO in 2021.',
      question: 'Which ancient Bronze Age civilization built Dholavira?',
      options: ['Maurya', 'Gupta', 'Indus Valley (Harappan)', 'Mughal'],
      correct_index: 2,
      explanation:
        'Dholavira is one of the five largest and most sophisticated cities of the Indus Valley (Harappan) civilization.',
      points: 20,
    },
  ],
};
